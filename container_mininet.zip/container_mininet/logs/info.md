## pasta que armazena logs de execução do docker
